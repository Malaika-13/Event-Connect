EventConnect - Flutter Venue Booking App (Full)

This archive contains:
- lib/main.dart (placeholder)
- pubspect.yaml
- venues.json, bookings.json, users.json
- android/ and windows/ placeholder folders

To prepare full project:
1) Replace lib/main.dart with the full main.dart code provided earlier (or keep as placeholder).
2) Run `flutter create .` in this folder to generate full platform files.
3) Run `flutter pub get`
4) Run `flutter run -d <device>`

Admin: admin / admin123
Categories: Resorts, Corporate Halls, Banquets, Marquees
